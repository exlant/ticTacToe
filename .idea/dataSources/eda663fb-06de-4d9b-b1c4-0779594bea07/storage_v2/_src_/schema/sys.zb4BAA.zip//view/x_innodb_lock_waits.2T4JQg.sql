create view `x$innodb_lock_waits` as
  select
    `r`.`trx_wait_started`                               as `wait_started`,
    timediff(now(), `r`.`trx_wait_started`)              as `wait_age`,
    timestampdiff(second, `r`.`trx_wait_started`, now()) as `wait_age_secs`,
    `rl`.`lock_table`                                    as `locked_table`,
    `rl`.`lock_index`                                    as `locked_index`,
    `rl`.`lock_type`                                     as `locked_type`,
    `r`.`trx_id`                                         as `waiting_trx_id`,
    `r`.`trx_started`                                    as `waiting_trx_started`,
    timediff(now(), `r`.`trx_started`)                   as `waiting_trx_age`,
    `r`.`trx_rows_locked`                                as `waiting_trx_rows_locked`,
    `r`.`trx_rows_modified`                              as `waiting_trx_rows_modified`,
    `r`.`trx_mysql_thread_id`                            as `waiting_pid`,
    `r`.`trx_query`                                      as `waiting_query`,
    `rl`.`lock_id`                                       as `waiting_lock_id`,
    `rl`.`lock_mode`                                     as `waiting_lock_mode`,
    `b`.`trx_id`                                         as `blocking_trx_id`,
    `b`.`trx_mysql_thread_id`                            as `blocking_pid`,
    `b`.`trx_query`                                      as `blocking_query`,
    `bl`.`lock_id`                                       as `blocking_lock_id`,
    `bl`.`lock_mode`                                     as `blocking_lock_mode`,
    `b`.`trx_started`                                    as `blocking_trx_started`,
    timediff(now(), `b`.`trx_started`)                   as `blocking_trx_age`,
    `b`.`trx_rows_locked`                                as `blocking_trx_rows_locked`,
    `b`.`trx_rows_modified`                              as `blocking_trx_rows_modified`,
    concat('KILL QUERY ', `b`.`trx_mysql_thread_id`)     as `sql_kill_blocking_query`,
    concat('KILL ', `b`.`trx_mysql_thread_id`)           as `sql_kill_blocking_connection`
  from ((((`information_schema`.`innodb_lock_waits` `w`
    join `information_schema`.`innodb_trx` `b` on ((`b`.`trx_id` = `w`.`blocking_trx_id`))) join
    `information_schema`.`innodb_trx` `r` on ((`r`.`trx_id` = `w`.`requesting_trx_id`))) join
    `information_schema`.`innodb_locks` `bl` on ((`bl`.`lock_id` = `w`.`blocking_lock_id`))) join
    `information_schema`.`innodb_locks` `rl` on ((`rl`.`lock_id` = `w`.`requested_lock_id`)))
  order by `r`.`trx_wait_started`;

