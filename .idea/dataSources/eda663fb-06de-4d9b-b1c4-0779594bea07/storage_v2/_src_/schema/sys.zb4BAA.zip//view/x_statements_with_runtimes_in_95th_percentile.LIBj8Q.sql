create view `x$statements_with_runtimes_in_95th_percentile` as
  select
    `stmts`.`DIGEST_TEXT`                                                                      as `query`,
    `stmts`.`SCHEMA_NAME`                                                                      as `db`,
    if(((`stmts`.`SUM_NO_GOOD_INDEX_USED` > 0) or (`stmts`.`SUM_NO_INDEX_USED` > 0)), '*', '') as `full_scan`,
    `stmts`.`COUNT_STAR`                                                                       as `exec_count`,
    `stmts`.`SUM_ERRORS`                                                                       as `err_count`,
    `stmts`.`SUM_WARNINGS`                                                                     as `warn_count`,
    `stmts`.`SUM_TIMER_WAIT`                                                                   as `total_latency`,
    `stmts`.`MAX_TIMER_WAIT`                                                                   as `max_latency`,
    `stmts`.`AVG_TIMER_WAIT`                                                                   as `avg_latency`,
    `stmts`.`SUM_ROWS_SENT`                                                                    as `rows_sent`,
    round(ifnull((`stmts`.`SUM_ROWS_SENT` / nullif(`stmts`.`COUNT_STAR`, 0)), 0), 0)           as `rows_sent_avg`,
    `stmts`.`SUM_ROWS_EXAMINED`                                                                as `rows_examined`,
    round(ifnull((`stmts`.`SUM_ROWS_EXAMINED` / nullif(`stmts`.`COUNT_STAR`, 0)), 0), 0)       as `rows_examined_avg`,
    `stmts`.`FIRST_SEEN`                                                                       as `first_seen`,
    `stmts`.`LAST_SEEN`                                                                        as `last_seen`,
    `stmts`.`DIGEST`                                                                           as `digest`
  from (`performance_schema`.`events_statements_summary_by_digest` `stmts`
    join `sys`.`x$ps_digest_95th_percentile_by_avg_us` `top_percentile`
      on ((round((`stmts`.`AVG_TIMER_WAIT` / 1000000), 0) >= `top_percentile`.`avg_us`)))
  order by `stmts`.`AVG_TIMER_WAIT` desc;

