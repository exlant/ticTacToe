create view schema_table_statistics as
  select
    `pst`.`OBJECT_SCHEMA`                                    as `table_schema`,
    `pst`.`OBJECT_NAME`                                      as `table_name`,
    `sys`.`format_time`(`pst`.`SUM_TIMER_WAIT`)              as `total_latency`,
    `pst`.`COUNT_FETCH`                                      as `rows_fetched`,
    `sys`.`format_time`(`pst`.`SUM_TIMER_FETCH`)             as `fetch_latency`,
    `pst`.`COUNT_INSERT`                                     as `rows_inserted`,
    `sys`.`format_time`(`pst`.`SUM_TIMER_INSERT`)            as `insert_latency`,
    `pst`.`COUNT_UPDATE`                                     as `rows_updated`,
    `sys`.`format_time`(`pst`.`SUM_TIMER_UPDATE`)            as `update_latency`,
    `pst`.`COUNT_DELETE`                                     as `rows_deleted`,
    `sys`.`format_time`(`pst`.`SUM_TIMER_DELETE`)            as `delete_latency`,
    `fsbi`.`count_read`                                      as `io_read_requests`,
    `sys`.`format_bytes`(`fsbi`.`sum_number_of_bytes_read`)  as `io_read`,
    `sys`.`format_time`(`fsbi`.`sum_timer_read`)             as `io_read_latency`,
    `fsbi`.`count_write`                                     as `io_write_requests`,
    `sys`.`format_bytes`(`fsbi`.`sum_number_of_bytes_write`) as `io_write`,
    `sys`.`format_time`(`fsbi`.`sum_timer_write`)            as `io_write_latency`,
    `fsbi`.`count_misc`                                      as `io_misc_requests`,
    `sys`.`format_time`(`fsbi`.`sum_timer_misc`)             as `io_misc_latency`
  from (`performance_schema`.`table_io_waits_summary_by_table` `pst` left join
    `sys`.`x$ps_schema_table_statistics_io` `fsbi`
      on (((`pst`.`OBJECT_SCHEMA` = `fsbi`.`table_schema`) and (`pst`.`OBJECT_NAME` = `fsbi`.`table_name`))))
  order by `pst`.`SUM_TIMER_WAIT` desc;

