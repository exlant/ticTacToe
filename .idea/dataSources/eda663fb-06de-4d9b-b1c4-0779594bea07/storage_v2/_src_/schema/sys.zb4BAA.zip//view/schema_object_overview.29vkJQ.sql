create view schema_object_overview as select
                                        `information_schema`.`routines`.`ROUTINE_SCHEMA` as `db`,
                                        `information_schema`.`routines`.`ROUTINE_TYPE`   as `object_type`,
                                        count(0)                                         as `count`
                                      from `information_schema`.`routines`
                                      group by `information_schema`.`routines`.`ROUTINE_SCHEMA`,
                                        `information_schema`.`routines`.`ROUTINE_TYPE`
                                      union select
                                              `information_schema`.`tables`.`TABLE_SCHEMA` as `TABLE_SCHEMA`,
                                              `information_schema`.`tables`.`TABLE_TYPE`   as `TABLE_TYPE`,
                                              count(0)                                     as `COUNT(*)`
                                            from `information_schema`.`tables`
                                            group by `information_schema`.`tables`.`TABLE_SCHEMA`,
                                              `information_schema`.`tables`.`TABLE_TYPE`
                                      union select
                                              `information_schema`.`statistics`.`TABLE_SCHEMA`                       as `TABLE_SCHEMA`,
                                              concat('INDEX (', `information_schema`.`statistics`.`INDEX_TYPE`,
                                                     ')')                                                            as `CONCAT('INDEX (', INDEX_TYPE, ')')`,
                                              count(
                                                  0)                                                                 as `COUNT(*)`
                                            from `information_schema`.`statistics`
                                            group by `information_schema`.`statistics`.`TABLE_SCHEMA`,
                                              `information_schema`.`statistics`.`INDEX_TYPE`
                                      union select
                                              `information_schema`.`triggers`.`TRIGGER_SCHEMA` as `TRIGGER_SCHEMA`,
                                              'TRIGGER'                                        as `TRIGGER`,
                                              count(0)                                         as `COUNT(*)`
                                            from `information_schema`.`triggers`
                                            group by `information_schema`.`triggers`.`TRIGGER_SCHEMA`
                                      union select
                                              `information_schema`.`events`.`EVENT_SCHEMA` as `EVENT_SCHEMA`,
                                              'EVENT'                                      as `EVENT`,
                                              count(0)                                     as `COUNT(*)`
                                            from `information_schema`.`events`
                                            group by `information_schema`.`events`.`EVENT_SCHEMA`
                                      order by `db`, `object_type`;

