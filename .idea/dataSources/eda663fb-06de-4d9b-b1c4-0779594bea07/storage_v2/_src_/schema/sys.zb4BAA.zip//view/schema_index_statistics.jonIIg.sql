create view schema_index_statistics as
  select
    `performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_SCHEMA`                         as `table_schema`,
    `performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_NAME`                           as `table_name`,
    `performance_schema`.`table_io_waits_summary_by_index_usage`.`INDEX_NAME`                            as `index_name`,
    `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_FETCH`                           as `rows_selected`,
    `sys`.`format_time`(
        `performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_FETCH`)                  as `select_latency`,
    `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_INSERT`                          as `rows_inserted`,
    `sys`.`format_time`(
        `performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_INSERT`)                 as `insert_latency`,
    `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_UPDATE`                          as `rows_updated`,
    `sys`.`format_time`(
        `performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_UPDATE`)                 as `update_latency`,
    `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_DELETE`                          as `rows_deleted`,
    `sys`.`format_time`(
        `performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_INSERT`)                 as `delete_latency`
  from `performance_schema`.`table_io_waits_summary_by_index_usage`
  where (`performance_schema`.`table_io_waits_summary_by_index_usage`.`INDEX_NAME` is not null)
  order by `performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_WAIT` desc;

