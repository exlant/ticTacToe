create view statements_with_full_table_scans as
  select
    `sys`.`format_statement`(`performance_schema`.`events_statements_summary_by_digest`.`DIGEST_TEXT`)                as `query`,
    `performance_schema`.`events_statements_summary_by_digest`.`SCHEMA_NAME`                                          as `db`,
    `performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`                                           as `exec_count`,
    `sys`.`format_time`(
        `performance_schema`.`events_statements_summary_by_digest`.`SUM_TIMER_WAIT`)                                  as `total_latency`,
    `performance_schema`.`events_statements_summary_by_digest`.`SUM_NO_INDEX_USED`                                    as `no_index_used_count`,
    `performance_schema`.`events_statements_summary_by_digest`.`SUM_NO_GOOD_INDEX_USED`                               as `no_good_index_used_count`,
    round((ifnull((`performance_schema`.`events_statements_summary_by_digest`.`SUM_NO_INDEX_USED` /
                   nullif(`performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`, 0)), 0) * 100),
          0)                                                                                                          as `no_index_used_pct`,
    `performance_schema`.`events_statements_summary_by_digest`.`SUM_ROWS_SENT`                                        as `rows_sent`,
    `performance_schema`.`events_statements_summary_by_digest`.`SUM_ROWS_EXAMINED`                                    as `rows_examined`,
    round((`performance_schema`.`events_statements_summary_by_digest`.`SUM_ROWS_SENT` /
           `performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`),
          0)                                                                                                          as `rows_sent_avg`,
    round((`performance_schema`.`events_statements_summary_by_digest`.`SUM_ROWS_EXAMINED` /
           `performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`),
          0)                                                                                                          as `rows_examined_avg`,
    `performance_schema`.`events_statements_summary_by_digest`.`FIRST_SEEN`                                           as `first_seen`,
    `performance_schema`.`events_statements_summary_by_digest`.`LAST_SEEN`                                            as `last_seen`,
    `performance_schema`.`events_statements_summary_by_digest`.`DIGEST`                                               as `digest`
  from `performance_schema`.`events_statements_summary_by_digest`
  where (((`performance_schema`.`events_statements_summary_by_digest`.`SUM_NO_INDEX_USED` > 0) or
          (`performance_schema`.`events_statements_summary_by_digest`.`SUM_NO_GOOD_INDEX_USED` > 0)) and
         (not ((`performance_schema`.`events_statements_summary_by_digest`.`DIGEST_TEXT` like 'SHOW%'))))
  order by round((ifnull((`performance_schema`.`events_statements_summary_by_digest`.`SUM_NO_INDEX_USED` /
                          nullif(`performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`, 0)), 0) *
                  100), 0) desc,
    `sys`.`format_time`(`performance_schema`.`events_statements_summary_by_digest`.`SUM_TIMER_WAIT`) desc;

