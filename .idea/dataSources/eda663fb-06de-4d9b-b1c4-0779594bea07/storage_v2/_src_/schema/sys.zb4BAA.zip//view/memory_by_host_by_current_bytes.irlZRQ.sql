create view memory_by_host_by_current_bytes as
  select
    if(isnull(`performance_schema`.`memory_summary_by_host_by_event_name`.`HOST`), 'background',
       `performance_schema`.`memory_summary_by_host_by_event_name`.`HOST`) as                                                `host`,
    sum(
        `performance_schema`.`memory_summary_by_host_by_event_name`.`CURRENT_COUNT_USED`) as                                 `current_count_used`,
    `sys`.`format_bytes`(sum(
                             `performance_schema`.`memory_summary_by_host_by_event_name`.`CURRENT_NUMBER_OF_BYTES_USED`)) as `current_allocated`,
    `sys`.`format_bytes`(ifnull((sum(
                                     `performance_schema`.`memory_summary_by_host_by_event_name`.`CURRENT_NUMBER_OF_BYTES_USED`)
                                 / nullif(sum(
                                              `performance_schema`.`memory_summary_by_host_by_event_name`.`CURRENT_COUNT_USED`),
                                          0)),
                                0)) as                                                                                       `current_avg_alloc`,
    `sys`.`format_bytes`(max(
                             `performance_schema`.`memory_summary_by_host_by_event_name`.`CURRENT_NUMBER_OF_BYTES_USED`)) as `current_max_alloc`,
    `sys`.`format_bytes`(sum(
                             `performance_schema`.`memory_summary_by_host_by_event_name`.`SUM_NUMBER_OF_BYTES_ALLOC`)) as    `total_allocated`
  from `performance_schema`.`memory_summary_by_host_by_event_name`
  group by if(isnull(`performance_schema`.`memory_summary_by_host_by_event_name`.`HOST`), 'background',
              `performance_schema`.`memory_summary_by_host_by_event_name`.`HOST`)
  order by sum(`performance_schema`.`memory_summary_by_host_by_event_name`.`CURRENT_NUMBER_OF_BYTES_USED`) desc;

