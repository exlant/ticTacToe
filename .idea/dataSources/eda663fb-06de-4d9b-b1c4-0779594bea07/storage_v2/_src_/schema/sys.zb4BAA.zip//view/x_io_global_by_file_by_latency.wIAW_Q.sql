create view `x$io_global_by_file_by_latency` as
  select
    `performance_schema`.`file_summary_by_instance`.`FILE_NAME`       as `file`,
    `performance_schema`.`file_summary_by_instance`.`COUNT_STAR`      as `total`,
    `performance_schema`.`file_summary_by_instance`.`SUM_TIMER_WAIT`  as `total_latency`,
    `performance_schema`.`file_summary_by_instance`.`COUNT_READ`      as `count_read`,
    `performance_schema`.`file_summary_by_instance`.`SUM_TIMER_READ`  as `read_latency`,
    `performance_schema`.`file_summary_by_instance`.`COUNT_WRITE`     as `count_write`,
    `performance_schema`.`file_summary_by_instance`.`SUM_TIMER_WRITE` as `write_latency`,
    `performance_schema`.`file_summary_by_instance`.`COUNT_MISC`      as `count_misc`,
    `performance_schema`.`file_summary_by_instance`.`SUM_TIMER_MISC`  as `misc_latency`
  from `performance_schema`.`file_summary_by_instance`
  order by `performance_schema`.`file_summary_by_instance`.`SUM_TIMER_WAIT` desc;

