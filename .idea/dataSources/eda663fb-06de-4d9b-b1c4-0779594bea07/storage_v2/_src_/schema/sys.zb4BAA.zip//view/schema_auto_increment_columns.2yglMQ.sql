create view schema_auto_increment_columns as
  select
    `information_schema`.`COLUMNS`.`TABLE_SCHEMA`                                                             as `table_schema`,
    `information_schema`.`COLUMNS`.`TABLE_NAME`                                                               as `table_name`,
    `information_schema`.`COLUMNS`.`COLUMN_NAME`                                                              as `column_name`,
    `information_schema`.`COLUMNS`.`DATA_TYPE`                                                                as `data_type`,
    `information_schema`.`COLUMNS`.`COLUMN_TYPE`                                                              as `column_type`,
    (locate('unsigned', `information_schema`.`COLUMNS`.`COLUMN_TYPE`) =
     0)                                                                                                       as `is_signed`,
    (locate('unsigned', `information_schema`.`COLUMNS`.`COLUMN_TYPE`) >
     0)                                                                                                       as `is_unsigned`,
    ((case `information_schema`.`COLUMNS`.`DATA_TYPE`
      when 'tinyint'
        then 255
      when 'smallint'
        then 65535
      when 'mediumint'
        then 16777215
      when 'int'
        then 4294967295
      when 'bigint'
        then 18446744073709551615 end) >> if((locate('unsigned', `information_schema`.`COLUMNS`.`COLUMN_TYPE`) > 0), 0,
                                             1))                                                              as `max_value`,
    `information_schema`.`TABLES`.`AUTO_INCREMENT`                                                            as `auto_increment`,
    (`information_schema`.`TABLES`.`AUTO_INCREMENT` / ((case `information_schema`.`COLUMNS`.`DATA_TYPE`
                                                        when 'tinyint'
                                                          then 255
                                                        when 'smallint'
                                                          then 65535
                                                        when 'mediumint'
                                                          then 16777215
                                                        when 'int'
                                                          then 4294967295
                                                        when 'bigint'
                                                          then 18446744073709551615 end) >> if((locate('unsigned',
                                                                                                       `information_schema`.`COLUMNS`.`COLUMN_TYPE`)
                                                                                                > 0), 0,
                                                                                               1)))           as `auto_increment_ratio`
  from (`INFORMATION_SCHEMA`.`COLUMNS`
    join `INFORMATION_SCHEMA`.`TABLES`
      on (((`information_schema`.`COLUMNS`.`TABLE_SCHEMA` = `information_schema`.`TABLES`.`TABLE_SCHEMA`) and
           (`information_schema`.`COLUMNS`.`TABLE_NAME` = `information_schema`.`TABLES`.`TABLE_NAME`))))
  where (
    (`information_schema`.`COLUMNS`.`TABLE_SCHEMA` not in ('mysql', 'sys', 'INFORMATION_SCHEMA', 'performance_schema'))
    and (`information_schema`.`TABLES`.`TABLE_TYPE` = 'BASE TABLE') and
    (`information_schema`.`COLUMNS`.`EXTRA` = 'auto_increment'))
  order by (`information_schema`.`TABLES`.`AUTO_INCREMENT` / ((case `information_schema`.`COLUMNS`.`DATA_TYPE`
                                                               when 'tinyint'
                                                                 then 255
                                                               when 'smallint'
                                                                 then 65535
                                                               when 'mediumint'
                                                                 then 16777215
                                                               when 'int'
                                                                 then 4294967295
                                                               when 'bigint'
                                                                 then 18446744073709551615 end) >> if((locate(
                                                                                                           'unsigned',
                                                                                                           `information_schema`.`COLUMNS`.`COLUMN_TYPE`)
                                                                                                       > 0), 0,
                                                                                                      1))) desc,
    ((case `information_schema`.`COLUMNS`.`DATA_TYPE`
      when 'tinyint'
        then 255
      when 'smallint'
        then 65535
      when 'mediumint'
        then 16777215
      when 'int'
        then 4294967295
      when 'bigint'
        then 18446744073709551615 end) >>
     if((locate('unsigned', `information_schema`.`COLUMNS`.`COLUMN_TYPE`) > 0), 0, 1));

