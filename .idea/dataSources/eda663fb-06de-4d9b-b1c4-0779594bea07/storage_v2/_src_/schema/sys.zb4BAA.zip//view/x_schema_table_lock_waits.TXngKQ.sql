create view `x$schema_table_lock_waits` as
  select
    `g`.`OBJECT_SCHEMA`                              as `object_schema`,
    `g`.`OBJECT_NAME`                                as `object_name`,
    `pt`.`THREAD_ID`                                 as `waiting_thread_id`,
    `pt`.`PROCESSLIST_ID`                            as `waiting_pid`,
    `sys`.`ps_thread_account`(`p`.`OWNER_THREAD_ID`) as `waiting_account`,
    `p`.`LOCK_TYPE`                                  as `waiting_lock_type`,
    `p`.`LOCK_DURATION`                              as `waiting_lock_duration`,
    `pt`.`PROCESSLIST_INFO`                          as `waiting_query`,
    `pt`.`PROCESSLIST_TIME`                          as `waiting_query_secs`,
    `ps`.`ROWS_AFFECTED`                             as `waiting_query_rows_affected`,
    `ps`.`ROWS_EXAMINED`                             as `waiting_query_rows_examined`,
    `gt`.`THREAD_ID`                                 as `blocking_thread_id`,
    `gt`.`PROCESSLIST_ID`                            as `blocking_pid`,
    `sys`.`ps_thread_account`(`g`.`OWNER_THREAD_ID`) as `blocking_account`,
    `g`.`LOCK_TYPE`                                  as `blocking_lock_type`,
    `g`.`LOCK_DURATION`                              as `blocking_lock_duration`,
    concat('KILL QUERY ', `gt`.`PROCESSLIST_ID`)     as `sql_kill_blocking_query`,
    concat('KILL ', `gt`.`PROCESSLIST_ID`)           as `sql_kill_blocking_connection`
  from (((((`performance_schema`.`metadata_locks` `g`
    join `performance_schema`.`metadata_locks` `p` on ((
      (`g`.`OBJECT_TYPE` = `p`.`OBJECT_TYPE`) and (`g`.`OBJECT_SCHEMA` = `p`.`OBJECT_SCHEMA`) and
      (`g`.`OBJECT_NAME` = `p`.`OBJECT_NAME`) and (`g`.`LOCK_STATUS` = 'GRANTED') and
      (`p`.`LOCK_STATUS` = 'PENDING')))) join `performance_schema`.`threads` `gt`
      on ((`g`.`OWNER_THREAD_ID` = `gt`.`THREAD_ID`))) join `performance_schema`.`threads` `pt`
      on ((`p`.`OWNER_THREAD_ID` = `pt`.`THREAD_ID`))) left join `performance_schema`.`events_statements_current` `gs`
      on ((`g`.`OWNER_THREAD_ID` = `gs`.`THREAD_ID`))) left join `performance_schema`.`events_statements_current` `ps`
      on ((`p`.`OWNER_THREAD_ID` = `ps`.`THREAD_ID`)))
  where (`g`.`OBJECT_TYPE` = 'TABLE');

